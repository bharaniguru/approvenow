<?php 
$lang['dashboard'] = "Dashboard";
$lang['home'] = "Home";
$lang['Transaction No'] = "asasasasasas asas";

//Vehical Master

//Vehical Master_View Starts
$lang['logistics'] = "Logistics";
$lang['view all'] = "View all";
$lang['in our spine'] = "in our spine";
$lang['you may add'] = "You may add";
$lang['here'] = "here";
$lang['view'] = "View";
$lang['add'] = "Add";
$lang['vehicle code'] = "Vehicle Code";
$lang['vehicle description'] = "Vehicle Description";
$lang['vehicle make'] = "Vehicle Make";
$lang['vehicle year'] = "Vehicle Year";
$lang['vehicle type'] = "Vehicle Type";
$lang['vehicle color'] = "Vehicle Color";
$lang['vehicle fuel type'] = "Vehicle Fuel Type";
$lang['vehicle number of seater'] = "Vehicle Number Of Seater";
$lang['vehicle engine number'] = "Vehicle Engine Number";
$lang['vehicle chassis number'] = "Vehicle Chassis Number";
$lang['vehicle meter reading'] = "Vehicle Meter Reading";
$lang['vehicle transmission'] = "Vehicle Transmission";
$lang['vehicle load capacity'] = "Vehicle Load Capacity";
$lang['vehicle city code'] = "Vehicle City Code";
$lang['vehicle old new'] = "Vehicle Old New";
$lang['vehicle purchase date'] = "Vehicle Purchase Date";
$lang['vehicle insurance type'] = "Vehicle Insurance Type";
$lang['vehicle insurance company name'] = "Vehicle Insurance Company Name";
$lang['vehicle insurance policy number'] = "Vehicle Insurance Policy Number";
$lang['vehicle insurance policy date'] = "Vehicle Insurance Policy Date";
$lang['vehicle insurance policy expiry date'] = "Vehicle Insurance Policy Expiry Date";
$lang['Vehicle Registration Number'] = "vehicle registration number";
$lang['vehicle registration date'] = "Vehicle Registration Date";
$lang['vehicle registration expiry date'] = "Vehicle Registration Expiry Date";
$lang['vehicle toll card type'] = "Vehicle Toll Card Type";
$lang['vehicle toll card number'] = "Vehicle Toll Card Number";
$lang['vehicle toll card expiry date'] = "Vehicle Toll Card Expiry Date";
$lang['vehicle use type'] = "Vehicle Use Type";
$lang['vehicle user code'] = "Vehicle User Code";
$lang['vehicle maintenence by'] = "Vehicle Maintenence By";
$lang['vehicle advertisement'] = "Vehicle Advertisement";
$lang['vehicle advertisement date'] = "Vehicle Advertisement Date";
$lang['vehicle status'] = "Vehicle Status";
$lang['vehicle active'] = "Vehicle Active";
$lang['vehicle created user id'] = "Vehicle Created User Id";
$lang['vehicle created date'] = "Vehicle Created Date";
$lang['vehicle updated user id'] = "Vehicle Updated User Id";
$lang['vehicle updated date'] = "Vehicle Updated Date";
$lang['vehicle transaction date'] = "Vehicle Transaction Date";
$lang['action'] = "Action";
//Vehical Master_View End

//Vehical Master_Add Starts
$lang['Description'] = "Description";
$lang['Vehicle Info'] = "Vehicle Info";
$lang['Insurance Info'] = "Insurance Info";
$lang['Registration Info'] = "Registration Info";
$lang['User Info'] = "User Info";
$lang['Attachments'] = "Attachments";
$lang['Make'] = "Make";
$lang['Fuel Type'] = "Fuel Type";
$lang['Vehicle Seat'] = "Vehicle Seat";
$lang['Year'] = "Year";
$lang['Color'] = "Color";
$lang['Engine No'] = "Engine No";
$lang['Chassis No'] = "Chassis No";
$lang['Meter Reading'] = "Meter Reading";
$lang['Transmission'] = "Transmission";
$lang['Load Capasity'] = "Load Capasity";
$lang['Purchase Date'] = "Purchase Date";
$lang['Insurance Type'] = "Insurance Type";
$lang['Company Name'] = "Company Name";
$lang['Policy Number'] = "Policy Number";
$lang['Policy Start Date'] = "Policy Start Date";
$lang['Policy Expiry Date'] = "Policy Expiry Date";
$lang['Reg Number'] = "Reg Number";
$lang['Reg Date'] = "Reg Date";
$lang['Reg Expiry Date'] = "Reg Expiry Date";
$lang['Policy Expiry Date'] = "Policy Expiry Date";
$lang['Toll Card Type'] = "Toll Card Type";
$lang['Toll Card Number'] = "Toll Card Number";
$lang['Toll Card Exp Dt'] = "Toll Card Exp Dt";
$lang['Maintained By'] = "Maintained By";
$lang['Adv On Vehicle'] = "Adv On Vehicle";
$lang['Advertisement Dt'] = "Advertisement Dt";
$lang['User Type'] = "User Type";
$lang['User'] = "User";
$lang['Sr No'] = "Sr No";
$lang['File Name'] = "File Name";
$lang['File Size'] = "File Size";
$lang['VEHICLE CODE'] = "VEHICLE CODE";
$lang['DESCRIPTION'] = "DESCRIPTION";
$lang['VEHICLE MAKE BY'] = "VEHICLE MAKE BY";
$lang['NUMBER OF SEAT'] = "NUMBER OF SEAT";
$lang['VEHICLE YEAR'] = "VEHICLE YEAR";
$lang['VEHICLE COLOR'] = "VEHICLE COLOR";
$lang['VEHICLE ENGINE NUMBER'] = "VEHICLE ENGINE NUMBER";
$lang['VEHICLE CHASSIS NUMBER'] = "VEHICLE CHASSIS NUMBER";
$lang['VEHICLE METER READING'] = "VEHICLE METER READING";
$lang['VEHICLE TRANSMISSION'] = "VEHICLE TRANSMISSION";
$lang['VEHICLE LOAD CAPASITY'] = "VEHICLE LOAD CAPASITY";
$lang['VEHICLE PURCHASE DATE'] = "VEHICLE PURCHASE DATE";
$lang['VEHICLE INSURANCE COMPANY NAME'] = "VEHICLE INSURANCE COMPANY NAME";
$lang['VEHICLE INSURANCE POLICY NO'] = "VEHICLE INSURANCE POLICY NO";
$lang['VEHICLE INSURANCE POLICY DATE'] = "VEHICLE INSURANCE POLICY DATE";
$lang['VEHICLE INSURANCE POLICY EXPIRY DATE'] = "VEHICLE INSURANCE POLICY EXPIRY DATE";
$lang['VEHICLE REGISTRATION NUMBER'] = "VEHICLE REGESTRATION NUMBER";
$lang['VEHICLE REGISTRATION DATE'] = "VEHICLE REGISTRATION DATE";
$lang['VEHICLE REGISTRATION EXPIRY DATE'] = "VEHICLE REGISTRATION EXPIRY DATE";
$lang['VEHICLE INSURANCE POLICY EXPIRY DATE'] = "VEHICLE INSURANCE POLICY EXPIRY DATE";
$lang['VEHICLE TOLL CARD TYPE'] = "VEHICLE TOLL CARD TYPE";
$lang['VEHICLE TOLL CARD NUMBER'] = "VEHICLE TOLL CARD NUMBER";
$lang['VEHICLE TOLL CARD EXPIRY DATE'] = "VEHICLE TOLL CARD EXPIRY DATE";
$lang['VEHICLE MAINTAINENCE BY'] = "VEHICLE MAINTAINENCE BY";
$lang['VEHICLE ADVERTISEMENT'] = "VEHICLE ADVERTISEMENT";
$lang['VEHICLE ADVERTISEMENT DATE'] = "VEHICLE ADVERTISEMENT DATE";
$lang['Remove'] = "Remove";
//Vehical Master_Add End

//Vehical Master_Edit Start
//Vehical Master_Edit Start
$lang['VEHICLE INSURANCE POLICY NUMBER'] = "VEHICLE INSURANCE POLICY NUMBER";
//Team Master Starts

//Team Master_Add Starts
$lang['Employee Code'] = "Employee Code";
$lang['Employee Name'] = "Employee Name";
$lang['Cell Phone'] = "Cell Phone";
$lang['Designation'] = "Designation";
$lang['Nationality'] = "Nationality";
$lang['Select'] = "Select";
$lang['Date of Birth'] = "Date of Birth";
$lang['Team'] = "Team";
$lang['City'] = "City";
$lang['From Date'] = "From Date";
$lang['Upto Date'] = "Upto Date";
$lang['Active'] = "Active?";
$lang['Browse'] = "Browse";
$lang['Reset'] = "Reset";
$lang['Cancel'] = "Cancel";
$lang['Enter'] = "Enter the correct details here...";
$lang['EMPLOYEE CODE'] = "EMPLOYEE CODE";
$lang['EMPLOYEE NAME'] = "EMPLOYEE NAME";
$lang['CELL PHONE NUMBER'] = "CELL PHONE NUMBER";
$lang['DATE OF BIRTH'] = "DATE OF BIRTH";
$lang['FROM DATE'] = "FROM DATE";
$lang['UPTO DATE'] = "UPTO DATE";
//Team Master_Add End

//Team Master_Edit Starts
$lang['Edit'] = "Edit";
//Team Master End

//Team Master_View Starts
$lang['Here'] = "here...";
$lang['View'] = "View";
$lang['Image Blog'] = "Image Blog";
$lang['Image File'] = "Image File";
$lang['Team Code'] = "Team Code";
$lang['City Code'] = "City Code";
$lang['active'] = "Active";
$lang['Created User Id'] = "Created User Id";
$lang['Created Date'] = "Created Date";
$lang['Updated User Id'] = "Updated User Id";
$lang['Updated Date'] = "Updated Date";
//Team Master_View End

//JobRequestTransaction_Add Starts
$lang['Reference'] = "Reference";
$lang['Address'] = "Address";
$lang['Details'] = "Details";
$lang['Confirm'] = "Confirm";
$lang['Direct'] = "Direct";
$lang['Opportunity'] = "Opportunity";
$lang['Sales Order'] = "Sales Order";
$lang['Sales Invoice'] = "Sales Invoice";
$lang['Reference Txn'] = "Reference Txn";
$lang['Select Reference Txn'] = "Select Reference Txn";
$lang['Reference Doc No'] = "Reference Doc No";
$lang['Reference Txn Dt'] = "Reference Txn Dt";
$lang['Country'] = "Country";
$lang['State'] = "State";
$lang['Area'] = "Area";
$lang['PO Box'] = "PO Box";
$lang['Mobile'] = "Mobile";
$lang['Phone'] = "Phone";
$lang['Customer ID'] = "Customer ID";
$lang['Customer Account'] = "Customer Account";
$lang['Appoinment Date'] = "Appoinment Date";
$lang['Txn Code'] = "Txn Code";
$lang['Txn Num'] = "Txn Num";
$lang['Date'] = "Date";
$lang['REFERENCE TRANSACTION NUMBER'] = "REFERENCE TRANSACTION NUMBER";
$lang['REFERENCE TRANSACTION DATE'] = "REFERENCE TRANSACTION DATE";
$lang['CONTACT NUMBER'] = "CONTACT NUMBER";
$lang['CONTACT PERSON'] = "CONTACT PERSON";
$lang['ADDRESS'] = "ADDRESS";
$lang['POSTAL CODE'] = "POSTAL CODE";
$lang['MOBILE NUMBER'] = "MOBILE NUMBER";
$lang['PHONE NUMBER'] = "PHONE NUMBER";
$lang['FAX NUMBER'] = "FAX NUMBER";
$lang['EMAIL ID'] = "EMAIL ID";
$lang['CUSTOMER ID'] = "CUSTOMER ID";
$lang['CUSTOMER ACCOUNT DESCRIPTION'] = "CUSTOMER ACCOUNT DESCRIPTION";
$lang['CUSTOMER ACCOUNT CODE'] = "CUSTOMER ACCOUNT CODE";
$lang['APPOINTMENT DATE'] = "APPOINTMENT DATE";
//JobRequestTransaction_Add End

//JobRequestTransaction_Edit Starts
//JobRequestTransaction_Edit End

//JobRequestTransaction_View Starts
$lang['Transaction Code'] = "Transaction Code";
$lang['Transaction Number'] = "Transaction Number";
$lang['Transaction Date'] = "Transaction Date";
$lang['Document Reference'] = "Document Reference";
$lang['Location Code'] = "Location Code";
$lang['Job Code'] = "Job Code";
$lang['Appointment Date'] = "Appointment Date";
$lang['Requested By'] = "Requested By";
$lang['Status'] = "Status";
$lang['Reference Transaction Code'] = "Reference Transaction Code";
$lang['Reference Transaction Number'] = "Reference Transaction Number";
$lang['Reference Transaction Date'] = "Reference Transaction Date";
$lang['Contact Number'] = "Contact Number";
$lang['Contact Person'] = "Contact Person";
$lang['Customer Id'] = "Customer Id";
$lang['Customer Account Code'] = "Customer Account Code";
$lang['Customer Account Description'] = "Customer Account Description";
$lang['Address1'] = "Address1";
$lang['Address2'] = "Address2";
$lang['Address3'] = "Address3";
$lang['Address4'] = "Address4";
$lang['Country Code'] = "Country Code";
$lang['State Code'] = "State Code";
$lang['City Code'] = "City Code";
$lang['City Area Code'] = "City Area Code";
$lang['Postal Code'] = "Postal Code";
$lang['Mobile Number'] = "Mobile Number";
$lang['Phone Number'] = "Phone Number";
$lang['Fax'] = "Fax";
$lang['Email'] = "Email";
$lang['Created Date'] = "Created Date";
$lang['Created User Id'] = "Created User Id";
$lang['Updated Date'] = "Updated Date";
$lang['Updated User Id'] = "Updated User Id";
$lang['Send Active'] = "Send Active";
$lang['Send Date'] = "Send Date";
$lang['Send User Id'] = "Send User Id";
$lang['Approve Active'] = "Approve Active";
$lang['Approve Date'] = "Approve Date";
$lang['Approve User Id'] = "Approve User Id";
$lang['Job Status'] = "Job Status";
$lang['Reference From'] = "Reference From";
$lang['Incomplete'] = "Incomplete";
$lang['approve'] = "Approve?";
$lang['Approved'] = "Approved";
$lang['Amended'] = "Amended";
$lang['Rejected'] = "Rejected";
//JobRequestTransaction_View End

//JobRequestTransaction Approval_View Start

//JobRequestTransaction Approval_View End

//JobStatusDashboard_View Start
$lang['Job Status Dashboard'] = "Job Status Dashboard";
$lang['View all Job Status Dashboard in our spine'] = "View all Job Status Dashboard in our spine";
$lang['Total Jobs'] = "Total Jobs";
$lang['Completed Jobs'] = "Completed Jobs";
$lang['Partially Completed Jobs'] = "Partially Completed Jobs";
$lang['ReScheduled Jobs'] = "ReScheduled Jobs";
$lang['Closed Jobs'] = "Closed Jobs";
$lang['Pending Jobs'] = "Pending Jobs";
$lang['Response date'] = "Response date";
$lang['Document No'] = "Document No";
$lang['Customer Name'] = "Customer Name";
$lang['Job'] = "Job";
$lang['Close'] = "Close";
//JobStatusDashboard_View Start

//LogisticsDashBoard_View Starts
$lang['Appointment Upto'] = "Appointment Upto";
$lang['City Area'] = "City Area";
$lang['Job Scheduled'] = "Job Scheduled";
$lang['To be scheduled'] = "To be scheduled";
$lang['Assign Schedule Transaction'] = "Assign Schedule Transaction";
$lang['Existing Schedule'] = "Existing Schedule";
$lang['Add New Schedule'] = "Add New Schedule";

//LogisticsDashBoard_view End

//AjaxLogisticsDashBoard_View Starts
$lang['Txn Number'] = "Txn Number";
$lang['Txn Date'] = "Txn Date";
//AjaxLogisticsDashBoard_View End

//ScheduleTransaction_View Starts
$lang['Reference Document'] = "Reference Document";
$lang['Transaction Status'] = "Transaction Status";
//ScheduleTransaction_View End

//ScheduleTransaction_Add End
$lang['Appointment Dt'] = "Appointment Dt";
$lang['TRANSACTION STATUS'] = "TRANSACTION STATUS";
//ScheduleTransaction_Add End

//ScheduleTransaction_Edit End
$lang['You may Edit'] = "You may Edit";
//ScheduleTransaction_Edit End

//ScheduleTransactionApprovalView Starts
//ScheduleTransactionApprovalView End

//MeasurementTransaction_View Start
$lang['SR Code'] = "SR Code";
$lang['Sales Reference Transaction Code'] = "Sales Reference Transaction Code";
$lang['Sales Reference Transaction Number'] = "Sales Reference Transaction Number";
$lang['Sales Reference Transaction Date'] = "Sales Reference Transaction Date";
$lang['Customer Type'] = "Customer Type";
$lang['Fax Number'] = "Fax Number";
//MeasurementTransaction_View End


//MeasurementTransaction_Add Start
$lang['Product'] = "Product";
$lang['Edit Existings'] = "Edit Existings";
$lang['Ref Transaction'] = "Ref Transaction";
$lang['Ref No'] = "Ref No";
$lang['Building Name'] = "Building Name";
$lang['Floor Number'] = "Floor Number";
$lang['Flat Number'] = "Flat Number";
$lang['Unit Type'] = "Unit Type";
$lang['Color Code'] = "Color Code";
$lang['Width'] = "Width";
$lang['Height'] = "Height";
$lang['Quantity'] = "Quantity";
$lang['Mount Type'] = "Mount Type";
$lang['Mount On'] = "Mount On";
$lang['Operation'] = "Operation";
$lang['Manual'] = "Manual";
$lang['Motorized'] = "Motorized";
$lang['Control'] = "Control";
$lang['Left'] = "Left";
$lang['Right'] = "Right";
$lang['Opening'] = "Opening";
$lang['Top'] = "Top";
$lang['Center'] = "Center";
$lang['Pelmet'] = "Pelmet";
$lang['Yes'] = "Yes";
$lang['No'] = "No";
$lang['Projection'] = "Projection";
$lang['Fasica'] = "Fasica";
$lang['Remarks'] = "Remarks";
$lang['BUILDING NAME'] = "BUILDING NAME";
$lang['FLOOR NUMBER'] = "FLOOR NUMBER";
$lang['FLAT NUMBER'] = "FLAT NUMBER";
$lang['FORMAT: 999.99'] = "FORMAT: 999.99";
$lang['QUANTITY'] = "QUANTITY";
$lang['PROJECTION'] = "PROJECTION";
$lang['FASICA'] = "FASICA";
$lang['REMARKS'] = "REMARKS";
$lang['TRANSACTION NUMBER'] = "TRANSACTION NUMBER";
$lang['TRANSACTION DATE'] = "TRANSACTION DATE";
$lang['FILE SIZE'] = "FILE SIZE";

//MeasurementTransaction_Add End

//Ajax Starts
$lang['prev'] = "Prev";
$lang['next'] = "Next";
$lang['file Size:'] = "File Size:";
$lang['delete'] = "Delete";
$lang['update'] = "Update";
$lang['save/Add More'] = "Save/Add More";
$lang['transaction'] = "Transaction";
$lang['save'] = "Save";
$lang['close'] = "Close";
//Ajax End

//ScheduleTrackingLogisticAjax Start
$lang['customer Info'] = "Customer Info";
$lang['distance'] = "Distance";
$lang['approx Time To Reach'] = "Approx Time To Reach";

//ScheduleTrackingLogisticAjax End

//ScheduleTrackingDashboard_View Starts
$lang['current Location'] = "Current Location";
$lang['select Job'] = "Select Job";
$lang['completed'] = "Completed";
$lang['rescheduled'] = "Rescheduled";
$lang['closed'] = "Closed";
$lang['not Scheduled'] = "Not Scheduled";
$lang['partialy Completed'] = "Partialy Completed";
$lang['scheduled'] = "Scheduled";
$lang['pending'] = "Pending";
$lang['re Scheduled Reason'] = "Re Scheduled Reason";
$lang['rescheduled Date'] = "Rescheduled Date";
//ScheduleTrackingDashboard_View End

//ScheduleTrackingDashboardUnKnownHostName_View Starts
$lang['CT_DESC'] = "CT_DESC";
$lang['CT_LATITUDE'] = "CT_LATITUDE";
$lang['CT_LONGITUDE'] = "CT_LONGITUDE";
//ScheduleTrackingDashboardUnKnownHostName_View End

$lang['delete record ?'] = "Are you conform to delete the record ?";


?>

